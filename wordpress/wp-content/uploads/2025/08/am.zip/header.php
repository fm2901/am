<?php ?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<a class="skip-link screen-reader-text" href="#content"><?php _e('Skip to content','nrg-classic'); ?></a>
<header class="header">
	<div class="container brand">
		<?php if ( has_custom_logo() ) { the_custom_logo(); } ?>
		<div>
			<a href="<?php echo esc_url( home_url('/') ); ?>"><h1 style="margin:0;"><?php bloginfo('name'); ?></h1></a>
			<p style="margin:.2rem 0 0 0;color:#6b7280;"><?php bloginfo('description'); ?></p>
		</div>
	</div>
	<nav class="container nav" aria-label="<?php esc_attr_e('Primary','nrg-classic'); ?>">
		<?php wp_nav_menu(['theme_location'=>'primary','container'=>false,'menu_class'=>'menu','fallback_cb'=>function(){ wp_page_menu(['show_home'=>true]); }]); ?>
	</nav>
</header>
<main id="content" class="container site-main">
