<article class="card">
	<h2><?php _e('Nothing Found','nrg-classic'); ?></h2>
	<p><?php _e('Sorry, but nothing matched your search terms. Please try again with different keywords.','nrg-classic'); ?></p>
	<?php get_search_form(); ?>
</article>
