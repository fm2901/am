</main>
<footer class="footer">
	<div class="container">
		<p>© <?php echo date_i18n('Y'); ?> <?php bloginfo('name'); ?>. <?php _e('All rights reserved.','nrg-classic'); ?></p>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
