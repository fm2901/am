<?php if ( post_password_required() ) return; ?>
<section id="comments" class="card" style="margin-top:1rem;">
	<?php if ( have_comments() ) : ?>
		<h2><?php comments_number( __('No Comments','nrg-classic'), __('1 Comment','nrg-classic'), __('% Comments','nrg-classic') ); ?></h2>
		<ol class="comment-list"><?php wp_list_comments(); ?></ol>
		<?php the_comments_pagination(); ?>
	<?php endif; ?>
	<?php comment_form(); ?>
</section>
