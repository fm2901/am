<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url('/') ); ?>">
	<label class="screen-reader-text" for="s"><?php _e('Search for:','nrg-classic'); ?></label>
	<input type="search" id="s" class="search-field" placeholder="<?php esc_attr_e('Search…','nrg-classic'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
	<button type="submit" class="search-submit"><?php esc_html_e('Search','nrg-classic'); ?></button>
</form>
