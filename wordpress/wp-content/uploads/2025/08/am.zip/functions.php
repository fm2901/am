<?php
if ( ! defined( 'NRG_CLASSIC_VER' ) ) define( 'NRG_CLASSIC_VER', '1.0.0' );
add_action( 'after_setup_theme', function() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', ['height'=>64,'width'=>64,'flex-height'=>true,'flex-width'=>true] );
	add_theme_support( 'html5', ['search-form','comment-form','comment-list','gallery','caption','style','script'] );
	register_nav_menus( ['primary'=> __( 'Primary Menu', 'nrg-classic' )] );
} );
add_action( 'wp_enqueue_scripts', function() {
	wp_enqueue_style( 'nrg-classic-style', get_stylesheet_uri(), [], NRG_CLASSIC_VER );
	wp_enqueue_style( 'nrg-classic-main', get_template_directory_uri() . '/assets/main.css', ['nrg-classic-style'], NRG_CLASSIC_VER );
	wp_enqueue_script( 'nrg-classic-js', get_template_directory_uri() . '/assets/scripts.js', [], NRG_CLASSIC_VER, true );
} );
add_action( 'widgets_init', function() {
	register_sidebar([
		'name'=>__( 'Sidebar', 'nrg-classic' ),
		'id'=>'sidebar-1',
		'description'=>__( 'Right sidebar', 'nrg-classic' ),
		'before_widget'=>'<section id="%1$s" class="widget %2$s card">',
		'after_widget'=>'</section>',
		'before_title'=>'<h3 class="widget-title">',
		'after_title'=>'</h3>',
	]);
} );
