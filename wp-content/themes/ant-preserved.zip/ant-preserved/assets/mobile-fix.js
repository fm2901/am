// Mobile menu toggler that works with hashed CSS modules
(function(){
  'use strict';
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function qs(sel, ctx){ return (ctx||document).querySelector(sel); }
  function qsa(sel, ctx){ return Array.from((ctx||document).querySelectorAll(sel)); }

  function findBurger(){
    // Prefer a button whose class contains "_burger_"
    var el = document.querySelector('button[class*="_burger_"]');
    if(el) return el;
    // Fallback: any button with 3 stacked spans
    return Array.from(document.querySelectorAll('button')).find(function(b){
      var spans = b.querySelectorAll('span');
      return spans.length>=1 && (getComputedStyle(spans[0]).height||'').includes('2');
    }) || null;
  }

  function findNav(){
    return document.querySelector('nav[class*="_navigation_"]');
  }

  function closeMenu(){
    document.documentElement.classList.remove('is-menu-open');
  }

  function openMenu(){
    document.documentElement.classList.add('is-menu-open');
  }

  function toggleMenu(){
    document.documentElement.classList.toggle('is-menu-open');
  }

  ready(function(){
    var burger = findBurger();
    var nav = findNav();
    if(!nav || !burger) return;

    // Toggle on burger click
    burger.addEventListener('click', toggleMenu);

    // Close on ESC
    document.addEventListener('keydown', function(e){
      if(e.key === 'Escape') closeMenu();
    });

    // Close when tapping any nav link
    qsa('nav[class*="_navigation_"] a').forEach(function(a){
      a.addEventListener('click', closeMenu);
    });

    // Close when resizing up to desktop
    var mq = window.matchMedia('(min-width: 992px)');
    function handle(e){ if(e.matches) closeMenu(); }
    if(mq.addEventListener) mq.addEventListener('change', handle); else mq.addListener(handle);

    // Optional: close when clicking the overlay (using html::before)
    document.addEventListener('click', function(e){
      if(!document.documentElement.classList.contains('is-menu-open')) return;
      var navEl = findNav();
      if(!navEl) return;
      if(!navEl.contains(e.target) && !e.target.closest('button[class*="_burger_"]')){
        closeMenu();
      }
    });
  });
})();
