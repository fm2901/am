<?php
if ( ! defined('ABSPATH') ) { exit; }
// Минимальный шаблон комментариев — ничего не выводим, но файл существует.
?>
<div id="comments" class="comments-area"></div>
