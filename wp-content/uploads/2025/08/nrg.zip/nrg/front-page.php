<?php /* Template: Front Page */ get_header(); ?>
<section class="hero">
	<div class="hero-card">
		<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/hero.jpg' ); ?>" alt="">
		<div class="overlay"></div>
		<div class="hero-content">
			<h1><?php _e('Барномаи "Мой АНТ"','nrg-classic-hero'); ?></h1>
			<p><?php _e('Ҳисоби шахсӣ, воситаҳои равшан ва дастрас','nrg-classic-hero'); ?></p>
			<a class="btn" href="#"><?php _e('Муфассал','nrg-classic-hero'); ?></a>
		</div>
	</div>
	<div class="features">
		<div class="feature"><div class="icon"><?php echo file_get_contents( get_template_directory().'/assets/img/icon-topup.svg'); ?></div><div><div class="name"><?php _e('Пур кардани тавозун','nrg-classic-hero'); ?></div><div class="desc"><?php _e('Бо як клик','nrg-classic-hero'); ?></div></div></div>
		<div class="feature"><div class="icon"><?php echo file_get_contents( get_template_directory().'/assets/img/icon-check.svg'); ?></div><div><div class="name"><?php _e('Санҷиши тавозун','nrg-classic-hero'); ?></div><div class="desc"><?php _e('Тез ва қулай','nrg-classic-hero'); ?></div></div></div>
		<div class="feature"><div class="icon"><?php echo file_get_contents( get_template_directory().'/assets/img/icon-internet.svg'); ?></div><div><div class="name"><?php _e('Бастаҳои пайвастшавӣ','nrg-classic-hero'); ?></div><div class="desc"><?php _e('Интернет/TV/телефон','nrg-classic-hero'); ?></div></div></div>
		<div class="feature"><div class="icon"><?php echo file_get_contents( get_template_directory().'/assets/img/icon-user.svg'); ?></div><div><div class="name"><?php _e('Ҳисоби шахсӣ','nrg-classic-hero'); ?></div><div class="desc"><?php _e('Идоракунии хизматҳо','nrg-classic-hero'); ?></div></div></div>
	</div>
</section>
<?php get_footer(); ?>
