<?php get_header(); ?>
<section>
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class('card'); ?>>
			<h1 style="margin-top:0;"><?php the_title(); ?></h1>
			<div class="entry-content"><?php the_content(); wp_link_pages(); ?></div>
		</article>
		<?php comments_template(); ?>
	<?php endwhile; endif; ?>
</section>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
