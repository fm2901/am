<?php get_header(); ?>
<section>
	<?php if ( have_posts() ) : ?>
		<div class="post-list">
		<?php while ( have_posts() ) : the_post(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class('card'); ?>>
				<?php if ( has_post_thumbnail() ) : ?><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('large',['class'=>'wp-post-image']); ?></a><?php endif; ?>
				<h2 style="margin:0 0 .5rem 0;"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				<div class="post-meta"><?php echo get_the_date(); ?> · <?php the_category(', '); ?></div>
				<div><?php the_excerpt(); ?></div>
				<p><a href="<?php the_permalink(); ?>"><?php _e('Read more →','nrg-classic-hero'); ?></a></p>
			</article>
		<?php endwhile; ?>
		</div>
		<?php the_posts_pagination(['mid_size'=>2]); ?>
	<?php else : ?>
		<?php get_template_part('template-parts/content','none'); ?>
	<?php endif; ?>
</section>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
