<?php ?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<a class="skip-link screen-reader-text" href="#content"><?php _e('Skip to content','nrg-classic-hero'); ?></a>
<div class="topbar">
	<div class="container row">
		<div><?php _e('Марказҳои хизматрасонӣ','nrg-classic-hero'); ?></div>
		<div class="lang-switch"><a href="#" class="active">RU</a><a href="#">TJ</a></div>
	</div>
</div>
<header class="header">
	<div class="container brand">
		<div class="logo"><div class="logo-badge">A</div><a href="<?php echo esc_url( home_url('/') ); ?>"><?php bloginfo('name'); ?></a></div>
	</div>
	<div class="container navbar">
		<?php wp_nav_menu(['theme_location'=>'primary','container'=>false,'menu_class'=>'menu','fallback_cb'=>function(){ echo '<ul class="menu"><li><a href="'.esc_url(home_url('/')).'">' . __('Главная','nrg-classic-hero') . '</a></li></ul>'; }]); ?>
		<div class="spacer"></div>
		<a class="btn" href="#"><?php _e('Ҳисоби шахсӣ','nrg-classic-hero'); ?></a>
		<a class="btn primary" href="#"><?php _e('Пайваст','nrg-classic-hero'); ?></a>
	</div>
</header>
<main id="content" class="container narrow">
