<?php get_header(); ?>
<section>
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class('card'); ?>>
			<h1 style="margin-top:0;"><?php the_title(); ?></h1>
			<div class="post-meta"><?php echo get_the_date(); ?> · <?php the_category(', '); ?></div>
			<?php if ( has_post_thumbnail() ) the_post_thumbnail('large',['class'=>'wp-post-image']); ?>
			<div class="entry-content"><?php the_content(); ?></div>
			<?php wp_link_pages(); ?>
			<p><?php the_tags(); ?></p>
		</article>
		<?php comments_template(); ?>
	<?php endwhile; endif; ?>
</section>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
