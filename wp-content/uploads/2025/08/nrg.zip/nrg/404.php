<?php get_header(); ?>
<section>
	<article class="card">
		<h1><?php _e('Page not found','nrg-classic-hero'); ?></h1>
		<p><?php _e('It looks like nothing was found at this location. Try a search.','nrg-classic-hero'); ?></p>
		<?php get_search_form(); ?>
	</article>
</section>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
