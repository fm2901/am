<aside class="sidebar">
  <?php if ( is_active_sidebar('primary') ) : dynamic_sidebar('primary'); else: ?>
    <div class="entry"><p><?php _e('Добавьте виджеты в боковую панель (Виджеты → Primary).', 'ant-classic'); ?></p></div>
  <?php endif; ?>
</aside>
