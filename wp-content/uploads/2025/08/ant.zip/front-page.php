<?php
/**
 * Шаблон фронтовой страницы (Страница → «Главная страница» + Настройки → Чтение → Отображать на главной: Статическая страница)
 */
get_header(); ?>

<section class="hero entry">
  <h1><?php bloginfo('name'); ?></h1>
  <p><?php bloginfo('description'); ?></p>
</section>

<?php
// Блок «Последние записи»
$q = new WP_Query([ 'posts_per_page' => 3 ]);
if ( $q->have_posts() ) : ?>
  <section class="latest grid">
    <?php while( $q->have_posts() ) : $q->the_post(); ?>
      <article <?php post_class('entry'); ?>>
        <?php if ( has_post_thumbnail() ) : ?>
          <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('large'); ?></a>
        <?php endif; ?>
        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <div class="excerpt"><?php the_excerpt(); ?></div>
      </article>
    <?php endwhile; wp_reset_postdata(); ?>
  </section>
<?php endif; ?>

<?php get_footer(); ?>
