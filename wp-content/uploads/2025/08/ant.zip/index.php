<?php get_header(); ?>
<?php if ( have_posts() ) : ?>
  <div class="grid grid-2">
    <section class="content">
      <?php while ( have_posts() ) : the_post(); ?>
        <article <?php post_class('entry'); ?>>
          <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <div class="meta"><?php echo get_the_date(); ?></div>
          <div class="excerpt"><?php the_excerpt(); ?></div>
        </article>
      <?php endwhile; ?>
      <div class="pagination"><?php the_posts_pagination(); ?></div>
    </section>
    <?php get_sidebar(); ?>
  </div>
<?php else : ?>
  <p><?php _e('Записей не найдено.', 'ant-classic'); ?></p>
<?php endif; ?>
<?php get_footer(); ?>
