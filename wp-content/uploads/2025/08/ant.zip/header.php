<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
  <div class="container brand">
    <div class="logo">
      <?php if ( has_custom_logo() ) { the_custom_logo(); } else { ?>
        <a href="<?php echo esc_url( home_url('/') ); ?>" class="site-name"><?php bloginfo('name'); ?></a>
      <?php } ?>
    </div>
    <button class="menu-toggle" data-toggle="primary-nav" aria-controls="primary-menu" aria-expanded="false">
      ☰ <span class="screen-reader-text"><?php _e('Открыть меню', 'ant-classic'); ?></span>
    </button>
  </div>
  <nav class="primary-nav" id="primary-nav" role="navigation" aria-label="<?php esc_attr_e('Основное меню', 'ant-classic'); ?>">
    <div class="container">
      <?php
        wp_nav_menu([
          'theme_location' => 'primary',
          'container' => false,
          'menu_class' => 'menu nav',
          'fallback_cb' => '__return_empty_string',
          'link_before' => '<span>',
          'link_after'  => '</span>',
        ]);
      ?>
    </div>
  </nav>
</header>
<main class="site-main container">
