(function(){
  'use strict';
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  ready(function(){
    var btn = document.querySelector('.menu-toggle');
    var nav = document.getElementById(btn && btn.getAttribute('data-toggle'));
    if(!btn || !nav) return;
    btn.addEventListener('click', function(){
      var open = nav.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  });
})();
