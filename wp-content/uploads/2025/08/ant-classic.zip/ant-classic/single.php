<?php get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
  <article <?php post_class('entry'); ?>>
    <h1><?php the_title(); ?></h1>
    <div class="meta"><?php echo get_the_date(); ?> • <?php the_category(', '); ?></div>
    <div class="content"><?php the_content(); ?></div>
    <?php the_tags('<p>Теги: ', ', ', '</p>'); ?>
    <?php comments_template(); ?>
  </article>
<?php endwhile; endif; ?>
<?php get_footer(); ?>
