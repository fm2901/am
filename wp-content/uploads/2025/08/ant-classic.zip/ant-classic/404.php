<?php get_header(); ?>
<section class="entry">
  <h1>404</h1>
  <p><?php _e('Страница не найдена.', 'ant-classic'); ?></p>
  <?php get_search_form(); ?>
</section>
<?php get_footer(); ?>
