<?php
/**
 * Основные функции темы
 * @package ant-classic
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'after_setup_theme', 'ant-classic_setup' );
function ant-classic_setup() {
  add_theme_support( 'title-tag' );
  add_theme_support( 'post-thumbnails' );
  add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ] );
  add_theme_support( 'custom-logo', [ 'height' => 80, 'width' => 80, 'flex-height' => true, 'flex-width' => true ] );

  register_nav_menus( [
    'primary' => __( 'Основное меню', 'ant-classic' ),
    'footer'  => __( 'Меню подвала', 'ant-classic' ),
  ] );
}

/** Подключение стилей/скриптов */
add_action( 'wp_enqueue_scripts', 'ant-classic_assets' );
function ant-classic_assets() {
  wp_enqueue_style( 'ant-classic', get_stylesheet_uri(), [], '1.0.0' );
  wp_enqueue_script( 'ant-classic-main', get_template_directory_uri() . '/assets/js/main.js', [], '1.0.0', true );
}

/** Вспомогательные: класс для body на главной */
add_filter( 'body_class', function( $classes ){ if( is_front_page() ) $classes[] = 'is-front'; return $classes; } );

/** Sidebar (widgets) */
add_action( 'widgets_init', function(){
  register_sidebar([
    'name' => __('Primary', 'ant-classic'),
    'id' => 'primary',
    'before_widget' => '<div id="%1$s" class="widget %2$s entry">',
    'after_widget'  => '</div>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>',
  ]);
});
