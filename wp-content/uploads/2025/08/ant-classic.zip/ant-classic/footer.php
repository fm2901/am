<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
</main>
<footer class="site-footer">
  <div class="container">
    <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> — <?php bloginfo('description'); ?></p>
    <nav class="footer-nav" aria-label="<?php esc_attr_e('Меню подвала', 'ant-classic'); ?>">
      <?php
        wp_nav_menu([
          'theme_location' => 'footer',
          'container' => false,
          'menu_class' => 'menu nav',
          'fallback_cb' => '__return_empty_string',
        ]);
      ?>
    </nav>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
