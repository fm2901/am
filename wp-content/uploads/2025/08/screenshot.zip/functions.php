<?php
/**
 * NRG Theme functions and definitions
 *
 * @package nrg-theme
 */

if ( ! defined( 'NRG_THEME_VERSION' ) ) {
	define( 'NRG_THEME_VERSION', '1.0.0' );
}

add_action( 'after_setup_theme', function () {
	// Поддержка возможностей редактора и темы
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'title-tag' );
	register_nav_menus( [
		'primary' => __( 'Primary Menu', 'nrg-theme' ),
	] );
} );

// Подключаем стили темы в редакторе (дополнительно к theme.json)
add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'nrg-editor', get_theme_file_uri( 'style.css' ), [], NRG_THEME_VERSION );
} );

// Для старых плагинов можно подключить файл front.css (по желанию)
// add_action( 'wp_enqueue_scripts', function () {
// 	wp_enqueue_style( 'nrg-frontend', get_theme_file_uri( 'front.css' ), [], NRG_THEME_VERSION );
// } );