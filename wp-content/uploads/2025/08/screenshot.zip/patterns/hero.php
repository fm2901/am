<?php
/**
 * Title: Hero Section
 * Slug: nrg-theme/hero
 * Categories: featured, text
 * Block Types: core/group
 * Inserter: yes
 */
?>
<!-- wp:cover {"dimRatio":20,"overlayColor":"primary","minHeight":380,"style":{"border":{"radius":"24px"}}} -->
<div class="wp-block-cover" style="border-radius:24px;min-height:380px"><span aria-hidden="true" class="wp-block-cover__background has-primary-background-color has-background-dim-20 has-background-dim"></span><div class="wp-block-cover__inner-container">
	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center">Заголовок секции</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center"} -->
	<p class="has-text-align-center">Короткий подзаголовок с призывом к действию.</p>
	<!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons"><!-- wp:button {"text":"Подробнее"} /--></div>
	<!-- /wp:buttons -->
</div></div>
<!-- /wp:cover -->